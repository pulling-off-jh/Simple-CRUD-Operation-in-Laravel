<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <nav class="navbar navbar-expand-sm bg-dark">

        <div class="container-fluid">
          <!-- Links -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link text-light" href="{{route('product.index')}}">Products</a>
            </li>
          </ul>
        </div>
      
      </nav>

      @if ($message = Session::get('success')){
        <div class="alert alert-success alert-block">
          <strong>{{ $message }}</strong>
        </div>
      }
          
      @endif

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card mt-3 p-2">
                    <form method="POST" action="{{route('product.store')}}" enctype="multipart/form-data">
                        @csrf
                        <!-- Name input -->
                        <div class="form-outline mb-4">
                          <label class="form-label" for="form4Example1">Name</label>
                          <input type="text" name="name" value="{{ old('name') }}" id="form4Example1" class="form-control" />
                          @if ($errors->has('name')){
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                          }   
                          @endif
                        </div>
                      
                        <!-- Message input -->
                        <div class="form-outline mb-4">
                          <label class="form-label" for="form4Example3">Description</label>
                          <textarea class="form-control" name="description" id="form4Example3" rows="4">{{ old('description') }}</textarea>
                          @if ($errors->has('description')){
                            <span class="text-danger">{{ $errors->first('description') }}</span>
                          }   
                          @endif
                        </div>

                        <!-- Image input -->
                        <div class="form-outline mb-4">
                          <label class="form-label" for="form4Example3">Image</label>
                          <input type="file" name="image" id="form4Example1" class="form-control" />
                          @if ($errors->has('image')){
                            <span class="text-danger">{{ $errors->first('image') }}</span>
                          }   
                          @endif
                        </div>  
                      
                        <!-- Submit button -->
                        <button type="submit" class="btn btn-primary btn-block mb-4">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>