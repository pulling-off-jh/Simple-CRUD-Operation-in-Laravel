<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <nav class="navbar navbar-expand-sm bg-dark">

        <div class="container-fluid">
          <!-- Links -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link text-light" href="<?php echo e(route('product.index')); ?>">Products</a>
            </li>
          </ul>
        </div>
      
      </nav>

      <?php if($message = Session::get('success')): ?>{
        <div class="alert alert-success alert-block">
          <strong><?php echo e($message); ?></strong>
        </div>
      }
      <?php endif; ?>
        
    <div class="container">
        <div class="row mt-3">
            <div class="text-end">
                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-info">Create New Product</a>
            </div>
            
            <table class="table table-hover mt-3">
              <thead>
                <tr>
                  <th>Sl No.</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Image</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->index+1); ?></td>
                  <td><a href="<?php echo e(route('product.show', ['id' => $product->id])); ?>" class="text-dark"><?php echo e($product->name); ?></a></td>
                  <td><?php echo e($product->description); ?></td>
                  <td>
                    <img src="product_img/<?php echo e($product->image); ?>" class="rounded-circle" width="50" height="50" alt="">
                  </td>
                  <td>
                    <a href="product/<?php echo e($product->id); ?>/edit" class="btn btn-success btn-sm">Edit</a>
                    <a href="product/<?php echo e($product->id); ?>/delete" class="btn btn-danger btn-sm">Delete</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

        </div>
    </div>



</body>
</html><?php /**PATH C:\xampp\htdocs\BASIS-SEIP\CRUD\crud\resources\views/products/index.blade.php ENDPATH**/ ?>