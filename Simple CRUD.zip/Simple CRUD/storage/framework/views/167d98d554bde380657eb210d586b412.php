<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <nav class="navbar navbar-expand-sm bg-dark">

        <div class="container-fluid">
          <!-- Links -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link text-light" href="<?php echo e(route('product.index')); ?>">Products</a>
            </li>
          </ul>
        </div>
      
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mt-4">
                <div class="card p-4">
                    <p>Name : <b> <?php echo e($product->name); ?> </b></p>
                    <p>Description : <b> <?php echo e($product->description); ?> </b></p>
                    <img src="<?php echo e(asset('/')); ?>product_img/<?php echo e($product->image); ?>" class="rounded-circle" width="100px" alt="">
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\BASIS-SEIP\CRUD\crud\resources\views/products/show.blade.php ENDPATH**/ ?>